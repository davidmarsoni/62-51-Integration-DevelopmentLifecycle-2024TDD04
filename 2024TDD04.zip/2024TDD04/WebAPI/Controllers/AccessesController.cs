﻿using DAL;
using DAL.Models;
using DTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPI.Mapper;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccessesController : ControllerBase
    {
        private readonly RoomAccessContext _context;

        public AccessesController(RoomAccessContext context)
        {
            _context = context;
        }

        private async Task<(bool isValid, ActionResult? errorResponse)> ValidateAccess(int roomId, int groupId)
        {
            var roomExists = await _context.Rooms.AnyAsync(r => r.Id == roomId && !r.IsDeleted);
            var groupExists = await _context.Groups.AnyAsync(g => g.Id == groupId);

            if (!roomExists || !groupExists)
                return (false, NotFound());

            return (true, null);
        }

        private async Task<(bool isValid, ActionResult? errorResponse)> ValidateUser(int userId)
        {
            var exists = await _context.Users.AnyAsync(u => u.Id == userId);
            return exists ? (true, null) : (false, NotFound());
        }

        private async Task<IQueryable<Access>> GetUserAccessesQuery(int userId)
        {
            var userGroupIds = await _context.UserGroups
                .Where(ug => ug.UserId == userId)
                .Select(ug => ug.GroupId)
                .ToListAsync();

            return _context.Accesses.Where(a => userGroupIds.Contains(a.GroupId));
        }

        private async Task<List<RoomDTO>> GetRoomsByAccessesQuery(IQueryable<Access> accessQuery)
        {
            return await accessQuery
                .Join(_context.Rooms,
                    a => a.RoomId,
                    r => r.Id,
                    (a, r) => RoomMapper.toDTO(r))
                .ToListAsync();
        }

        [HttpGet("HasAccessGroup/{roomId}/{groupId}")]
        public async Task<ActionResult<bool>> HasAccessGroupAsync(int roomId, int groupId)
        {
            var (isValid, errorResponse) = await ValidateAccess(roomId, groupId);
            if (!isValid) return errorResponse!;

            return await _context.Accesses.AnyAsync(a => 
                a.RoomId == roomId && a.GroupId == groupId);
        }

        [HttpGet("HasAccessUser/{roomId}/{userId}")]
        public async Task<ActionResult<bool>> HasAccessUserAsync(int roomId, int userId)
        {
            var (isValid, errorResponse) = await ValidateUser(userId);
            if (!isValid) return errorResponse!;

            var accessQuery = await GetUserAccessesQuery(userId);
            return await accessQuery.AnyAsync(a => a.RoomId == roomId);
        }

        [HttpGet("GetAccessesByUserId/{userId}")]
        public async Task<ActionResult<IEnumerable<RoomDTO>>> GetAccessesByUserId(int userId)
        {
            var (isValid, errorResponse) = await ValidateUser(userId);
            if (!isValid) return errorResponse!;

            var accessQuery = await GetUserAccessesQuery(userId);
            var rooms = await GetRoomsByAccessesQuery(accessQuery);
            
            return rooms.Any() ? rooms : NoContent();
        }

        [HttpGet("GetAccessesByGroupId/{groupId}")]
        public async Task<ActionResult<IEnumerable<RoomDTO>>> GetAccessesByGroupId(int groupId)
        {
            if (!await _context.Groups.AnyAsync(g => g.Id == groupId))
                return NotFound();

            var accessQuery = _context.Accesses.Where(a => a.GroupId == groupId);
            return await GetRoomsByAccessesQuery(accessQuery);
        }

        [HttpPost("GrantAccess")]
        public async Task<ActionResult<bool>> GrantAccessAsync(AccessDTO accessDTO)
        {
            var (isValid, errorResponse) = await ValidateAccess(accessDTO.RoomId, accessDTO.GroupId);
            if (!isValid) return errorResponse!;

            if (await _context.Accesses.AnyAsync(a => 
                a.RoomId == accessDTO.RoomId && a.GroupId == accessDTO.GroupId))
                return Conflict();

            _context.Accesses.Add(AccessMapper.toDAL(accessDTO));
            await _context.SaveChangesAsync();
            return true;
        }

        [HttpPost("RevokeAccess")]
        public async Task<ActionResult<bool>> RevokeAccessAsync(AccessDTO accessDTO)
        {
            var (isValid, errorResponse) = await ValidateAccess(accessDTO.RoomId, accessDTO.GroupId);
            if (!isValid) return errorResponse!;

            var access = await _context.Accesses.FirstOrDefaultAsync(a => 
                a.RoomId == accessDTO.RoomId && a.GroupId == accessDTO.GroupId);
            
            if (access == null) return NotFound();

            _context.Accesses.Remove(access);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}