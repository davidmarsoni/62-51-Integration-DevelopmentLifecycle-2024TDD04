namespace DTO
{
    public class RoomAccessDTO
    {
        public int RoomId { get; set; }
        public int UserId { get; set; }
    }
}