using DAL;
using DAL.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace _2024TDD04.DAL.Tests.Models
{
    public class RoomAccessContextTest
    {

    }
}
